let cart=[];
function addToCart(name,price){cart.push({name,price});renderCart();document.getElementById('cart').classList.add('open')}
function renderCart(){
 const box=document.getElementById('cartItems');
 document.getElementById('cartCount').textContent=cart.length;
 if(!cart.length){box.innerHTML='Your cart is empty.';document.getElementById('total').textContent='0';return;}
 box.innerHTML=cart.map((x,i)=>`<div class="cart-line"><span>${x.name}</span><span>$${x.price}</span></div>`).join('');
 document.getElementById('total').textContent=cart.reduce((a,x)=>a+x.price,0);
}
function toggleCart(){document.getElementById('cart').classList.toggle('open')}
function checkout(){alert('Your order button works! Connect a payment/order system here when you are ready. 💗')}
